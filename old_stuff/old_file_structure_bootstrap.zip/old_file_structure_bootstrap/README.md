# raghavp96.github.io

# Todos:
Some things I will be considering in the future:
- removing high school related information            _Kept, but is simplified now_
- uploading resume                                    _Done_
- discussing some projects I've done                  _Done_
- get rid of template pictures, and keep only my own  _Done_
